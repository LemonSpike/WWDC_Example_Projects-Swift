Phantom from Space by Kevin MacLeod is licensed under CC Attribution 3.0.

Direct Link: http://incompetech.com/music/royalty-free/index.html?isrc=USUAN1500038.