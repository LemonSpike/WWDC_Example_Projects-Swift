//
//  PersonCell.swift
//  Project10
//
//  Created by TwoStraws on 17/08/2016.
//  Copyright © 2016 Paul Hudson. All rights reserved.
//

import UIKit

class PersonCell: UICollectionViewCell {
	@IBOutlet weak var imageView: UIImageView!
	@IBOutlet weak var name: UILabel!
}
